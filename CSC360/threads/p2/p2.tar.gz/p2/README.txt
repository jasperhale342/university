To create an executable file, type make into the command line and press enter
To run the file that is in the folder on the code, type make m into the command line and press enter
to delete the executable file, type make clean into the command line and press enter
